#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# string
str_a = "Obstacle is the way"
print("str_a=		" , 	str_a)
print("str_a[5]=	" , 	str_a[5])
print("str_a[7:]=	" , 	str_a[7:])
print("str_a[:7]=	" ,	str_a[:7])
print("str_a[5:9]=	" ,	str_a[5:9])
print("str_a * 2 =	" ,	str_a * 2)
print("str_a+' Success'=" ,	str_a + " Success")
print("\n")


str_b = "  Obstacle is the way  "
print("str_b=                " , str_b)
print("str_b.split()=        " , str_b.split())
print("str_b.split()[0]=     " , str_b.split()[0])
print("str_b.strip()=        " , str_b.strip())
str_b = str_b.strip()
print("str_b[::-1]=reverse=  " , str_b[::-1])
print("str_b.replace('way','way ahead')=        " , str_b.replace('way','way ahead'))
str_b = str_b.replace('way','way ahead')
print("str_b=                " , str_b)
print("\n")





